/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.dao;

import br.entity.ItemEntrada;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author marcio
 */
public class RegistroDao {

    private Conexao conexao = Conexao.getInstance();
    private ItemEntrada itemEntrada;
    private PreparedStatement preparedStatement;
    private ResultSet resultSet;
    private String sql;

    public void registrarEntrada() {
        try {
            setSql("insert into entrada (data, fornecedor_idfornecedor, funcionario_idfuncionario) "
                    + "values (now(),?,?)");
            setPreparedStatement(conexao.getConnection().prepareStatement(getSql()));
            getPreparedStatement().setInt(1, itemEntrada.getEntrada().getFornecedor().getIdFornecedor());
            getPreparedStatement().setInt(2, itemEntrada.getEntrada().getFuncionario().getIdFuncionario());
            System.out.println("sql " + getPreparedStatement());
            getPreparedStatement().executeUpdate();
            setSql("select max(identrada) from entrada");
            setPreparedStatement(conexao.getConnection().prepareStatement(getSql()));
            setResultSet(getPreparedStatement().executeQuery());
            getResultSet().next();
            itemEntrada.getEntrada().setIdEntrada(getResultSet().getInt(1));
            setSql("insert into item_Entrada (entrada_identrada, produto_idproduto, quantidade, valor_compra) "
                    + "values(?,?,?,?)");
            setPreparedStatement(conexao.getConnection().prepareStatement(getSql()));
            getPreparedStatement().setInt(1, itemEntrada.getEntrada().getIdEntrada());
            getPreparedStatement().setInt(2, itemEntrada.getProduto().getIdProduto());
            getPreparedStatement().setInt(3, itemEntrada.getQuantidade());
            getPreparedStatement().setDouble(4, itemEntrada.getValorCompra());
            System.out.println("sql " + getPreparedStatement());
            getPreparedStatement().executeUpdate();

            setSql("update produto set valor_venda = ?, quantidade = ? where idproduto = ?");
            setPreparedStatement(conexao.getConnection().prepareStatement(getSql()));
            getPreparedStatement().setDouble(1, getItemEntrada().getProduto().getValorVenda());
            System.out.println("intens entrando "+getItemEntrada().getQuantidade());
            System.out.println("itens agora " + getItemEntrada().getProduto().getQuantidade());
            getPreparedStatement().setInt(2, (getItemEntrada().getProduto().getQuantidade() + getItemEntrada().getQuantidade()));
            getPreparedStatement().setInt(3, getItemEntrada().getProduto().getIdProduto());
            System.out.println("update produto " + getPreparedStatement());
            getPreparedStatement().executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(RegistroDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public ItemEntrada getItemEntrada() {
        return itemEntrada;
    }

    public void setItemEntrada(ItemEntrada itemEntrada) {
        this.itemEntrada = itemEntrada;
    }

    public PreparedStatement getPreparedStatement() {
        return preparedStatement;
    }

    public void setPreparedStatement(PreparedStatement preparedStatement) {
        this.preparedStatement = preparedStatement;
    }

    public String getSql() {
        return sql;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }

    public ResultSet getResultSet() {
        return resultSet;
    }

    public void setResultSet(ResultSet resultSet) {
        this.resultSet = resultSet;
    }
}
